# Requirements

You need >= python3.6 to run this script. The websocket part uses async/await
syntax.

You need ```websockets```. You can do ```pip install -r requirements.txt``` to
install all the python package requirements.

# Run the bot

```python3 example_ai.py```
